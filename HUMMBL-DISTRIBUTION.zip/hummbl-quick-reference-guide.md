# HUMMBL Distribution Sprint - Quick Reference Guide
**Purpose:** Fast decision-making during execution

---

## When You're Not Sure What to Do

### The Priority Question (P1: First Principles)

**Ask:** "Does this directly increase active users?"

- ✅ **YES** → Do it now
- 🤔 **MAYBE** → Does it enable something that increases users? If yes, schedule it. If no, defer.
- ❌ **NO** → Don't do it this month

**Examples:**
- Post X thread? → YES (direct user acquisition)
- Perfect test coverage? → NO (infrastructure, not distribution)
- Reply to comments? → YES (engagement → conversion)
- Refactor relationship code? → NO (no user impact)
- Build `/examples` page? → YES (network effects → users)

---

## When You're Overwhelmed

### The 80/20 Filter (DE3: Pareto Principle)

**Ask:** "Which 20% of activities drive 80% of user growth?"

**This sprint, the vital few are:**
1. **X threads** → Impressions → Traffic → Users
2. **Direct outreach** → Immediate circle → Referrals
3. **MCP server** → Developer community → Stars → Users

**Everything else is the trivial many:**
- Documentation improvements
- Code refactoring
- Theoretical formalization
- New features (unless requested by users)

**Rule:** Spend 80% of time on the vital few, max 20% on everything else.

---

## When You Want to Build Something

### The MVP Test (DE1: First Principles + CO2: Minimum Viable Product)

**Ask:** "What's the minimum version that tests the hypothesis?"

**Example:**
- **Hypothesis:** Case studies drive conversion
- **NOT MVP:** Beautiful case study CMS with voting, comments, tags, analytics
- **IS MVP:** Simple grid page with 3 case studies (Problem → Models → Outcome)

**Rule:** Ship the minimum, measure impact, then improve. Don't build v2 before v1 proves value.

---

## When You're Procrastinating

### The Eat the Frog (P3: Prioritization)

**Ask:** "What's the hardest/scariest task today?"

**Do that first.**

**Why:** The hardest task is usually the most important. Everything else feels easy after.

**This sprint, common "frogs":**
- Sending outreach emails (rejection fear)
- Posting threads (judgment fear)
- Asking for testimonials (imposing fear)
- Launching on Product Hunt (failure fear)

**Rule:** Do the frog by 10am. Rest of day is downhill.

---

## When Results Aren't Coming

### The Pivot/Persevere Decision (IN3: Premortem + RE2: Feedback Loops)

**Ask:** "Is this not working yet, or not working at all?"

**Not working YET:** Early, data insufficient, need more time  
**Not working AT ALL:** Data clear, channel is dead, pivot now

**Decision framework:**

| Metric | Not Working Yet | Not Working At All |
|--------|----------------|-------------------|
| X threads | <1000 impressions after 2 posts | <100 impressions after 4 posts |
| Outreach | <20% response after 10 emails | <5% response after 30 emails |
| GitHub | <100 stars after 1 week | <50 stars after 2 weeks |

**Rule:** 
- Week 1-2: Persevere (too early to tell)
- Week 3: Evaluate (sufficient data?)
- Week 4: Pivot or double down (clear signal)

---

## When You're Tempted to Add Features

### The YAGNI Principle (DE4: Eisenhower Matrix)

**Ask:** "Do users need this NOW, or am I solving a future problem?"

**You Aren't Gonna Need It (YAGNI) until:**
- 3+ users explicitly request it
- It blocks core workflow
- It's essential for next user milestone

**This sprint, resist building:**
- Advanced analytics dashboard
- Custom model creation tools
- AI-powered recommendations
- Mobile app
- API v2

**This sprint, only build what's in the plan:**
- Week 1: `/examples` page, share feature, referral tracking
- Week 2: MCP server alpha
- Week 3: Community voting
- Week 4: "Suggest model" feature

**Rule:** If it's not in the 4-week plan, it waits until Week 5.

---

## When You're Losing Focus

### The North Star Metric (SY1: Systems Thinking)

**Ask:** "What's the ONE number that matters most?"

**This sprint:** **Active Users**

**Not:**
- GitHub stars (vanity metric)
- X impressions (leading indicator, not outcome)
- Code quality (important, but not the goal)
- Feature completeness (means, not end)

**Every decision filters through:** "Does this increase active users this month?"

**Rule:** Check active user count daily. If it's not growing, something's wrong.

---

## When You're Sacrificing Other Priorities

### The Constraint Preservation (CO3: Constraint Optimization)

**Ask:** "Am I protecting my non-negotiable constraints?"

**Non-negotiables this sprint:**
- Life Time: 40 hrs/week (revenue cannot drop)
- Law School: 5 hrs/week minimum (LSAT prep continues)
- Sleep: 7+ hours/night (cognitive work requires rest)
- Training: 3x/week (your mental model: embodied cognition)

**If any constraint is breaking:**
- HUMMBL gets cut, not the constraints
- Distribution sprint pauses or ends
- No exceptions

**Rule:** Constraints exist because they protect long-term success. Short-term HUMMBL gains aren't worth long-term damage.

---

## When Opportunity Cost Feels High

### The Reversibility Check (IN2: Inversion)

**Ask:** "If this fails, what did I lose? Can I get it back?"

**Low reversibility (high risk):**
- Quitting Life Time job
- Dropping law school prep
- Taking on debt for HUMMBL
- Burning bridges with consulting clients

**High reversibility (low risk):**
- 30-day distribution sprint
- 10 hrs/week on HUMMBL
- X thread campaign (if it flops, delete and move on)
- MCP server (open source, no commitment)

**This sprint is HIGH REVERSIBILITY:**
- If it works → Scale up
- If it doesn't → Lost 30 days and learned something
- Life Time, law school, consulting all preserved

**Rule:** Only take irreversible risks when data strongly supports them. This sprint is exploration, not commitment.

---

## When Someone Requests Your Time

### The Hell Yes or No Filter (P4: Opportunity Cost)

**Ask:** "Is this a 'Hell Yes' for growing active users?"

**If YES:**
- User wants to schedule call → Hell yes (potential case study)
- Podcast invite to discuss HUMMBL → Hell yes (distribution)
- Request to write guest post → Hell yes (audience access)

**If NO or MAYBE:**
- "Can you help with my project?" → No (doesn't grow HUMMBL)
- "Want to grab coffee?" → No (unless they're potential user)
- "Check out my product?" → No (not your goal right now)

**Rule:** This month, your time is expensive. Protect it aggressively.

---

## When Metrics Look Bad

### The Leading vs Lagging Indicator (RE2: Feedback Loops)

**Ask:** "Am I measuring the right thing for this stage?"

**Leading indicators (predict future):**
- X thread impressions
- Profile visits  
- Email open rates
- Reply rates to outreach

**Lagging indicators (measure past):**
- Active users
- Case studies published
- Referrals made

**Week 1-2:** Focus on leading indicators (are we reaching people?)  
**Week 3-4:** Focus on lagging indicators (are they converting?)

**Rule:** Don't panic about lagging indicators in Week 1. They lag. Focus on leading indicators first.

---

## When You Want to Quit

### The Sunk Cost Reality Check (IN2: Inversion)

**Ask:** "Am I continuing because it's working, or because I've invested time?"

**Good reasons to continue:**
- Users are growing
- Engagement is increasing
- People are asking for access
- Testimonials are emerging
- One channel is clearly working

**Bad reasons to continue:**
- "I've already built so much"
- "I can't waste that work"
- "I told people I'd do this"
- "Quitting feels like failure"

**This sprint has explicit kill criteria:**
- Day 15: <15 users → Reassess
- Day 22: <40 users → Consider pivot
- Day 29: <20 users → Major rethink

**Rule:** Past investment is sunk. Only future potential matters. Be brutally honest at checkpoints.

---

## Summary Decision Tree

```
Is it directly growing active users?
├─ YES → Do it now
└─ NO → Is it ENABLING something that grows users?
    ├─ YES → Schedule it (but users come first)
    └─ NO → Does it protect constraints (Life Time, sleep, law school)?
        ├─ YES → Do it (constraints are sacred)
        └─ NO → DON'T DO IT THIS MONTH
```

---

## Emergency Mantras

**When overwhelmed:** "Users > Features"

**When distracted:** "Distribution > Development"

**When perfectionist:** "Shipped > Perfect"

**When scared:** "Scary = Important"

**When tempted to build:** "YAGNI until 3 users ask"

**When metrics lag:** "Leading indicators first"

**When exhausted:** "Constraints are non-negotiable"

**When comparing:** "My path, my pace"

---

## The Meta-Model

**This entire sprint uses SY6: Playbooks**

You're executing a PLAYBOOK:
- 30 days
- 3 channels
- Clear metrics
- Explicit kill criteria
- Protected constraints

**Playbooks work when:**
- You follow the script
- You track the metrics
- You make course corrections
- You respect the timeline

**Playbooks fail when:**
- You improvise too much
- You ignore the data
- You extend deadlines
- You violate constraints

**This guide helps you follow the playbook.**

---

**Use this document when:**
- Making daily priority decisions
- Feeling uncertain or stuck
- Tempted to deviate from plan
- Evaluating opportunities
- Facing sprint checkpoints

**Upload to NotebookLM and ask:**
- "Should I do [task]?"
- "I'm stuck on [decision], what framework applies?"
- "What's my priority when [situation]?"

---

**Version:** 1.0  
**Last Updated:** 09 NOV 2025